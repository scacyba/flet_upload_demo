import flet as ft

def main(page: ft.Page):
    def handle_upload(e):
        if not e.files:
            return
        uploaded_file = e.files[0]
        page.controls.append(
            ft.Text(f"アップロードされたファイル: {uploaded_file.name}")
        )
        page.controls.append(
            ft.Image(src=uploaded_file.path, width=300)
        )
        page.update()

    file_picker = ft.FilePicker(on_result=handle_upload)
    page.overlay.append(file_picker)

    page.add(
        ft.ElevatedButton(
            "画像をアップロード",
            on_click=lambda _: file_picker.pick_files(
                allow_multiple=False,
                allowed_extensions=["jpg", "jpeg", "png", "gif"]
            )
        )
    )

ft.app(target=main)
